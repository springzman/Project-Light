module.exports = {
    Main(x) { console.log(`[Main] ${x}`) },
    Error(x) { console.log(`[Error] ${x}`) }
}