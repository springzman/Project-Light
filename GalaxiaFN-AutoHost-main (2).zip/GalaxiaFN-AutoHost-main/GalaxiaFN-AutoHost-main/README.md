# Fortnite Autohost Emulator

This program was made for Fortnite players to be able to play the old game with a launcher that can emulate the old game file to the new one

If an Epic Games employee want to contact me, they can contact me with discord: Waslyl

# IMPORTANT
!!! It is needed to add a function on your gameserver to make it crash at the end of the game so the autorestart will notice that to restart the client

## REQUIREMENTS
- [Cobalt](https://github.com/Milxnor/Cobalt/tree/main) (Rename your SSL as **redirect.dll**)
- [Gameserver](https://github.com/Milxnor/Project-Reboot-3.0) (Need to rename your gs as **gameserver.dll**)
- [Visual Studio](https://visualstudio.microsoft.com/fr/thank-you-downloading-visual-studio/?sku=Community&channel=Release&version=VS2022&source=VSLandingPage&cid=2030&passive=false) (Have basic knowledge to run an app (really difficult for some people))

## INSTALLATION

1. Download the Project
2. Replace **debug** to **release** and **Any CPU** to **x64**
3. Launch the program
4. Put your SSL (redirect.dll) and your Gameserver (gameserver.dll) in the same folder as the program
5. Open the application and follow the instructions

***If you need help with the autohost, you can contact me via [Discord](https://discord.gg/galaxiafn-1141260363715854336) or you can create a message in issues***

**All right are deserved by Waslyl**, you can use it for your own purpose but please *credit me*😁
